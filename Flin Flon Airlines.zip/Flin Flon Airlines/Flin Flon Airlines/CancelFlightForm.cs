﻿//CancelFlightForm.cs
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace Flin_Flon_Airlines
{
    public partial class CancelFlightForm : Form
    {
        private BookingAgent employee;
        private Passenger passenger;
        private Flight flight;

        public CancelFlightForm(BookingAgent employee)
        {
            InitializeComponent();
            this.employee = employee;
            UpdatePassengerListView();
        }

        public void UpdatePassengerListView()
        {
            passenger = null;
            passengerListView.Items.Clear();

            List<ListViewItem> items = new List<ListViewItem>();

            foreach (Passenger passenger in GlobalVars.passengerList)
            {
                ListViewItem item = new ListViewItem();
                item.Text = passenger.Id.ToString();
                item.SubItems.Add(passenger.FirstName);
                item.SubItems.Add(passenger.LastName);
                item.SubItems.Add(passenger.EmailAddress);
                item.SubItems.Add(passenger.HomeAddress);
                item.SubItems.Add(passenger.PhoneNumber);
                item.SubItems.Add(passenger.CreditCardNumber);
                item.SubItems.Add(passenger.Disability.ToString());
                items.Add(item);
            }

            passengerListView.Items.AddRange(items.ToArray());
        }

        public void UpdateFlightListView()
        {
            flight = null;
            flightListView.Items.Clear();

            if (passenger != null)
            {
                passenger.Update();
                List<ListViewItem> items = new List<ListViewItem>();

                foreach (Flight flight in passenger.BookedFlights)
                {
                    ListViewItem item = new ListViewItem();
                    item.Text = flight.Id.ToString();
                    item.SubItems.Add(flight.Origin);
                    item.SubItems.Add(flight.Destination);
                    item.SubItems.Add(flight.DepartureTime.ToString());
                    item.SubItems.Add(flight.Seats.ToString());
                    item.SubItems.Add(flight.SeatsLeft.ToString());
                    items.Add(item);
                }

                flightListView.Items.AddRange(items.ToArray());
            }
        }

        private void refreshPassengerButton_Click(object sender, System.EventArgs e)
        {
            UpdatePassengerListView();
            UpdateFlightListView();
        }

        private void refreshFlightButton_Click(object sender, System.EventArgs e)
        {
            if (passenger != null)
            {
                passenger = Passenger.GetPassenger(passenger.Id);
                UpdateFlightListView();
            }
        }

        private void passengerListView_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (passengerListView.SelectedItems.Count > 0)
            {
                passenger = Passenger.GetPassenger(int.Parse(passengerListView.SelectedItems[0].Text));
                UpdateFlightListView();
            }

            else
            {
                passenger = null;
                UpdateFlightListView();
            }
        }

        private void flightListView_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (flightListView.SelectedItems.Count > 0)
                flight = Flight.GetFlight(int.Parse(flightListView.SelectedItems[0].Text));

            else
                flight = null;
        }

        private async void cancelFlightButton_Click(object sender, System.EventArgs e)
        {
            if (passenger == null || flight == null)
                MessageBox.Show("Please choose a passenger and flight to cancel", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else
            {
                await employee.CancelFlight(passenger, flight);
                passenger.Update();
                MessageBox.Show("Successfully Cancelled", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateFlightListView();
            }
        }
    }
}
