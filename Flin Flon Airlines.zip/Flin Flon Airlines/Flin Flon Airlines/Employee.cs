﻿//Employee.cs
namespace Flin_Flon_Airlines
{
    public abstract class Employee
    {
        private int id;
        private string username;
        private string password;
        private bool isAdmin;
        protected LoginForm loginForm;

        public Employee(int id, string username, string password, bool isAdmin)
        {
            Id = id;
            Username = username;
            Password = password;
            IsAdmin = isAdmin;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public bool IsAdmin
        {
            get { return isAdmin; }
            set { isAdmin = value; }
        }

        public static Employee GetEmployee(int id)
        {
            return Database.GetEmployee(id);
        }

        public abstract void ShowForm(LoginForm loginForm);

        protected void Form_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            loginForm.Show();
        }
    }
}
