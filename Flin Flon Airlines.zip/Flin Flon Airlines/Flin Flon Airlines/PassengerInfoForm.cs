﻿//PassengerInfoForm.cs
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class PassengerInfoForm : Form
    {
        public PassengerInfoForm()
        {
            InitializeComponent();
            UpdatePassengerComboBox();
        }

        public void UpdatePassengerComboBox()
        {
            passengerComboBox.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();
            passengerComboBox.Items.AddRange(GlobalVars.passengerList.ToArray());
        }

        public void UpdatePassengerInfoListView()
        {
            passengerInfoListView.Items.Clear();

            if (passengerComboBox.SelectedIndex >= 0)
            {
                Passenger passenger = (Passenger)passengerComboBox.SelectedItem;
                ListViewItem item = new ListViewItem();
                item.Text = passenger.Id.ToString();
                item.SubItems.Add(passenger.FirstName);
                item.SubItems.Add(passenger.LastName);
                item.SubItems.Add(passenger.EmailAddress);
                item.SubItems.Add(passenger.HomeAddress);
                item.SubItems.Add(passenger.PhoneNumber);
                item.SubItems.Add(passenger.CreditCardNumber);
                item.SubItems.Add(passenger.Disability.ToString());

                passengerInfoListView.Items.Add(item);
            }
        }

        private void passengerComboBox_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdatePassengerInfoListView();
        }

        private void passengerComboBox_DropDown(object sender, System.EventArgs e)
        {
            if (passengerComboBox.SelectedItem == null)
                passengerInfoListView.Items.Clear();
        }
    }
}
