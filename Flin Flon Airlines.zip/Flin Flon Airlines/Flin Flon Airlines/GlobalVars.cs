﻿//GlobalVars.cs
using System.Collections.Generic;

namespace Flin_Flon_Airlines
{
    static class GlobalVars
    {
        public static List<Passenger> passengerList = new List<Passenger>();
        public static List<Flight> flightList = new List<Flight>();

        static GlobalVars()
        {
            UpdatePassengerAndFlightList();
        }

        public static void UpdatePassengerAndFlightList()
        {
            if (passengerList.Count > 0)
                passengerList.Clear();

            if (flightList.Count > 0)
                flightList.Clear();

            List<Passenger> passengers = Database.GetPassengerList();
            List<Flight> flights = Database.GetFlightList();

            if (passengers.Count > 0)
                passengerList.AddRange(passengers);

            if (flights.Count > 0)
                flightList.AddRange(flights);
        }
    }
}
