﻿//UpdateFlightForm.cs
using System;
using System.Linq;
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class UpdateFlightForm : Form
    {
        private SystemAdmin employee;

        public UpdateFlightForm(SystemAdmin employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        public void UpdateFlightComboBox()
        {
            flightComboBox.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();
            flightComboBox.Items.AddRange(GlobalVars.flightList.ToArray());
        }

        public void FillInFlightInfo(Flight flight)
        {
            idTextBox.Text = flight.Id.ToString();
            originTextBox.Text = flight.Origin;
            destinationTextBox.Text = flight.Destination;
            dateTimePicker1.Value = flight.DepartureTime;
            seatsNumericUpDown.Value = flight.Seats;
        }

        private void flightComboBox_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (flightComboBox.SelectedIndex >= 0)
                FillInFlightInfo((Flight)flightComboBox.SelectedItem);
        }

        public void ClearFlightInfo()
        {
            idTextBox.Clear();
            originTextBox.Clear();
            destinationTextBox.Clear();
            seatsNumericUpDown.Value = 0;
        }

        private void flightComboBox_DropDown(object sender, System.EventArgs e)
        {
            UpdateFlightComboBox();

            if (flightComboBox.SelectedItem == null)
                ClearFlightInfo();
        }

        private async void updateButton_Click(object sender, EventArgs e)
        {
            Flight flight = (Flight)flightComboBox.SelectedItem;

            if (flight == null)
            {
                MessageBox.Show("Please choose a flight", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            else if(originTextBox.Text.Length <= 0 || destinationTextBox.Text.Length <= 0)
            {
                Controls.OfType<TextBox>().Where(tbox => tbox.Text.Length <= 0).Last().Focus();
                MessageBox.Show("Please confirm inputs and try again", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            else if(dateTimePicker1.Value < DateTime.Now)
            {
                MessageBox.Show("Invalid departure time", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            else if (seatsNumericUpDown.Value <= 0)
            {
                MessageBox.Show("Invalid number of seats", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            int id = Int32.Parse(idTextBox.Text);
            string origin = originTextBox.Text;
            string destination = destinationTextBox.Text;
            DateTime departureTime = dateTimePicker1.Value;
            int seats = (int)seatsNumericUpDown.Value;
            int seatsLeft = seats - (flight.Seats - flight.SeatsLeft);

            if (seatsLeft < 0)
                seatsLeft = 0;

            await employee.UpdateFlight(new Flight(id, origin, destination, departureTime, seats, seatsLeft));

            MessageBox.Show("Flight Updated", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Dispose();
        }
    }
}
