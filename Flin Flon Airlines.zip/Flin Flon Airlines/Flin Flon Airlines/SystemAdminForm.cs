﻿//SystemAdminForm.cs
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class SystemAdminForm : Form
    {
        private SystemAdmin employee;
        private AddPassengerForm addPassengerForm;
        private PassengerInfoForm passengerInfoForm;
        private BookFlightForm bookFlightForm;
        private CancelFlightForm cancelFlightForm;
        private AddFlightForm addFlightForm;
        private UpdateFlightForm updateFlightForm;
        private SearchFlightForm searchFlightForm;
        private BoardingPassForm boardingPassForm;

        public SystemAdminForm(SystemAdmin employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private void addToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (addPassengerForm == null || addPassengerForm.IsDisposed)
            {
                addPassengerForm = new AddPassengerForm(employee);
                addPassengerForm.MdiParent = this;
            }

            addPassengerForm.Show();
            addPassengerForm.Activate();
            addPassengerForm.WindowState = FormWindowState.Normal;
        }

        private void informationToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (passengerInfoForm == null || passengerInfoForm.IsDisposed)
            {
                passengerInfoForm = new PassengerInfoForm();
                passengerInfoForm.MdiParent = this;
            }

            passengerInfoForm.Show();
            passengerInfoForm.Activate();
            passengerInfoForm.WindowState = FormWindowState.Normal;
        }

        private void bookToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            if (bookFlightForm == null || bookFlightForm.IsDisposed)
            {
                bookFlightForm = new BookFlightForm(employee);
                bookFlightForm.MdiParent = this;
            }

            bookFlightForm.Show();
            bookFlightForm.Activate();
            bookFlightForm.WindowState = FormWindowState.Normal;
        }

        private void cancelToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (cancelFlightForm == null || cancelFlightForm.IsDisposed)
            {
                cancelFlightForm = new CancelFlightForm(employee);
                cancelFlightForm.MdiParent = this;
            }

            cancelFlightForm.Show();
            cancelFlightForm.Activate();
            cancelFlightForm.WindowState = FormWindowState.Normal;
        }

        private void addToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            if (addFlightForm == null || addFlightForm.IsDisposed)
            {
                addFlightForm = new AddFlightForm(employee);
                addFlightForm.MdiParent = this;
            }

            addFlightForm.Show();
            addFlightForm.Activate();
            addFlightForm.WindowState = FormWindowState.Normal;
        }

        private void updateToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (updateFlightForm == null || updateFlightForm.IsDisposed)
            {
                updateFlightForm = new UpdateFlightForm(employee);
                updateFlightForm.MdiParent = this;
            }

            updateFlightForm.Show();
            updateFlightForm.Activate();
            updateFlightForm.WindowState = FormWindowState.Normal;
        }

        private void searchToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (searchFlightForm == null || searchFlightForm.IsDisposed)
            {
                searchFlightForm = new SearchFlightForm(employee);
                searchFlightForm.MdiParent = this;
            }

            searchFlightForm.Show();
            searchFlightForm.Activate();
            searchFlightForm.WindowState = FormWindowState.Normal;
        }

        private void boardingPassToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (boardingPassForm == null || boardingPassForm.IsDisposed)
            {
                boardingPassForm = new BoardingPassForm(employee);
                boardingPassForm.MdiParent = this;
            }

            boardingPassForm.Show();
            boardingPassForm.Activate();
            boardingPassForm.WindowState = FormWindowState.Normal;
        }
    }
}
