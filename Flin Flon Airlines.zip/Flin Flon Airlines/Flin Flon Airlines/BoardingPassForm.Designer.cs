﻿namespace Flin_Flon_Airlines
{
    partial class BoardingPassForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.passengerComboBox = new System.Windows.Forms.ComboBox();
            this.issueButton = new System.Windows.Forms.Button();
            this.flightListView = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Choose A Passenger:";
            // 
            // passengerComboBox
            // 
            this.passengerComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.passengerComboBox.FormattingEnabled = true;
            this.passengerComboBox.Location = new System.Drawing.Point(12, 25);
            this.passengerComboBox.MaxDropDownItems = 100;
            this.passengerComboBox.Name = "passengerComboBox";
            this.passengerComboBox.Size = new System.Drawing.Size(150, 21);
            this.passengerComboBox.TabIndex = 8;
            this.passengerComboBox.DropDown += new System.EventHandler(this.passengerComboBox_DropDown);
            this.passengerComboBox.SelectedIndexChanged += new System.EventHandler(this.passengerComboBox_SelectedIndexChanged);
            // 
            // issueButton
            // 
            this.issueButton.Location = new System.Drawing.Point(188, 157);
            this.issueButton.Name = "issueButton";
            this.issueButton.Size = new System.Drawing.Size(75, 23);
            this.issueButton.TabIndex = 11;
            this.issueButton.Text = "Issue";
            this.issueButton.UseVisualStyleBackColor = true;
            this.issueButton.Click += new System.EventHandler(this.issueButton_Click);
            // 
            // flightListView
            // 
            this.flightListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.flightListView.FullRowSelect = true;
            this.flightListView.HideSelection = false;
            this.flightListView.Location = new System.Drawing.Point(12, 52);
            this.flightListView.MultiSelect = false;
            this.flightListView.Name = "flightListView";
            this.flightListView.Size = new System.Drawing.Size(426, 97);
            this.flightListView.TabIndex = 12;
            this.flightListView.UseCompatibleStateImageBehavior = false;
            this.flightListView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Id";
            this.columnHeader9.Width = 30;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Origin";
            this.columnHeader10.Width = 90;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Destination";
            this.columnHeader11.Width = 90;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Departure Time";
            this.columnHeader12.Width = 100;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Seats";
            this.columnHeader13.Width = 43;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Seats Left";
            this.columnHeader14.Width = 63;
            // 
            // BoardingPassForm
            // 
            this.AcceptButton = this.issueButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 192);
            this.Controls.Add(this.flightListView);
            this.Controls.Add(this.issueButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.passengerComboBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "BoardingPassForm";
            this.ShowIcon = false;
            this.Text = "Boarding Pass";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox passengerComboBox;
        private System.Windows.Forms.Button issueButton;
        private System.Windows.Forms.ListView flightListView;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
    }
}