﻿//SearchFlightForm.cs
using System.Windows.Forms;
using System.Collections.Generic;

namespace Flin_Flon_Airlines
{
    public partial class SearchFlightForm : Form
    {
        private SystemAdmin employee;

        public SearchFlightForm(SystemAdmin employee)
        {
            InitializeComponent();
            this.employee = employee;
            UpdateOriginComboBox();
            UpdateDestinationComboBox();
        }

        public void UpdateOriginComboBox()
        {
            originComboBox.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();
            HashSet<string> mySet = new HashSet<string>();

            foreach(Flight flight in GlobalVars.flightList)
                mySet.Add(flight.Origin);

            foreach(string origin in mySet)
                originComboBox.Items.Add(origin);
        }

        public void UpdateDestinationComboBox()
        {
            destinationComboBox.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();
            HashSet<string> mySet = new HashSet<string>();

            foreach (Flight flight in GlobalVars.flightList)
                mySet.Add(flight.Destination);

            foreach (string destination in mySet)
                destinationComboBox.Items.Add(destination);
        }

        public void UpdateFlightListView()
        {
            flightListView.Items.Clear();

            List<Flight> flights = GlobalVars.flightList.FindAll(f => f.DepartureTime.Date >= firstDateTimePicker.Value.Date && f.DepartureTime.Date <= secondDateTimePicker.Value.Date);

            if (flights.Count > 0)
            {
                if(originComboBox.SelectedItem == null || destinationComboBox.SelectedItem == null)
                {
                    if (destinationComboBox.SelectedItem == null)
                        flights = flights.FindAll(f => f.Origin == (string)originComboBox.SelectedItem);

                    else if (originComboBox.SelectedItem == null)
                        flights = flights.FindAll(f => f.Destination == (string)destinationComboBox.SelectedItem);

                    foreach (Flight flight in flights)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = flight.Id.ToString();
                        item.SubItems.Add(flight.Origin);
                        item.SubItems.Add(flight.Destination);
                        item.SubItems.Add(flight.DepartureTime.ToString());
                        item.SubItems.Add(flight.Seats.ToString());
                        item.SubItems.Add(flight.SeatsLeft.ToString());
                        flightListView.Items.Add(item);
                    }
                }

                else
                {
                    flights = flights.FindAll(f => f.Origin == (string)originComboBox.SelectedItem && f.Destination == (string)destinationComboBox.SelectedItem);

                    foreach (Flight flight in flights)
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = flight.Id.ToString();
                        item.SubItems.Add(flight.Origin);
                        item.SubItems.Add(flight.Destination);
                        item.SubItems.Add(flight.DepartureTime.ToString());
                        item.SubItems.Add(flight.Seats.ToString());
                        item.SubItems.Add(flight.SeatsLeft.ToString());
                        flightListView.Items.Add(item);
                    }
                }
            }
        }

        private void originComboBox_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdateFlightListView();
        }

        private void destinationComboBox_SelectedIndexChanged_1(object sender, System.EventArgs e)
        {
            UpdateFlightListView();
        }

        private void firstDateTimePicker_ValueChanged(object sender, System.EventArgs e)
        {
            UpdateFlightListView();
        }

        private void secondDateTimePicker_ValueChanged(object sender, System.EventArgs e)
        {
            UpdateFlightListView();
        }
    }
}
