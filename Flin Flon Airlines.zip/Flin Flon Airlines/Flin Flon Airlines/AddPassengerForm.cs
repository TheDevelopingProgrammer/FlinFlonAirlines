﻿//AddPassengerForm.cs
using System;
using System.Windows.Forms;
using System.Linq;

namespace Flin_Flon_Airlines
{
    public partial class AddPassengerForm : Form
    {
        private BookingAgent employee;

        public AddPassengerForm(BookingAgent employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private async void addButton_Click(object sender, EventArgs e)
        {
            bool valid = true;
            var emptyTextBoxes = Controls.OfType<TextBox>().Where(tbox => tbox.Text.Length <= 0);

            if (emptyTextBoxes.Count() > 0)
            {
                emptyTextBoxes.Last().Focus();
                valid = false;
            }

            else if (Controls.OfType<RadioButton>().Where(radio => radio.Checked).Count() <= 0)
                valid = false;

            else if (phoneNumberBox.Text.Length < 10 || creditCardNumberBox.Text.Length < 16)
                valid = false;

            if (!valid)
            {
                MessageBox.Show("Please confirm inputs and try again", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string firstName = firstNameBox.Text;
            string lastName = lastNameBox.Text;
            string emailAddress = emailAddressBox.Text;
            string homeAddress = homeAddressBox.Text;
            string phoneNumber = phoneNumberBox.Text;
            string creditCardNumber = creditCardNumberBox.Text;
            bool disability = yesRadioButton.Checked ? true : false;

            await employee.AddPassenger(new Passenger(firstName, lastName, emailAddress, homeAddress, phoneNumber, creditCardNumber, disability));

            MessageBox.Show("Passenger Added", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Dispose();
        }

        private void phoneNumberBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && (Keys)e.KeyChar != Keys.Back && (Control.ModifierKeys & Keys.Control) != Keys.Control)
                e.Handled = true;
        }

        private void creditCardNumberBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && (Keys)e.KeyChar != Keys.Back && (Control.ModifierKeys & Keys.Control) != Keys.Control)
                e.Handled = true;
        }
    }
}
