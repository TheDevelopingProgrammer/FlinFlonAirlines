﻿//LoginForm.cs
using System;
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Login(int id)
        {
            Employee employee = Employee.GetEmployee(id);

            if (employee != null)
                employee.ShowForm(this);
        }

        private async void loginButton_Click(object sender, EventArgs e)
        {
            string username = usernameBox.Text;
            string password = passwordBox.Text;

            if (username.Length <= 0 || !await Database.UserExists(username))
            {
                MessageBox.Show("Invalid Username", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                usernameBox.Focus();
                usernameBox.SelectAll();
                return;
            }

            else if (password.Length <= 0 || !await Database.MatchLogin(username, password))
            {
                MessageBox.Show("Invalid Password", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                passwordBox.Focus();
                passwordBox.SelectAll();
                return;
            }
            
            Login(await Database.GetUserId(username));

            usernameBox.Clear();
            passwordBox.Clear();
            usernameBox.Select();
        }
    }
}
