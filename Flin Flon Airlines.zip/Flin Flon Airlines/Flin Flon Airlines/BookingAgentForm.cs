﻿//BookingAgentForm.cs
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class BookingAgentForm : Form
    {
        private BookingAgent employee;
        private AddPassengerForm addPassengerForm;
        private PassengerInfoForm passengerInfoForm;
        private BookFlightForm bookFlightForm;
        private CancelFlightForm cancelFlightForm;
        private BoardingPassForm boardingPassForm;

        public BookingAgentForm(BookingAgent employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private void addToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (addPassengerForm == null || addPassengerForm.IsDisposed)
            {
                addPassengerForm = new AddPassengerForm(employee);
                addPassengerForm.MdiParent = this;
            }

            addPassengerForm.Show();
            addPassengerForm.Activate();
            addPassengerForm.WindowState = FormWindowState.Normal;
        }

        private void boardingPassToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (boardingPassForm == null || boardingPassForm.IsDisposed)
            {
                boardingPassForm = new BoardingPassForm(employee);
                boardingPassForm.MdiParent = this;
            }

            boardingPassForm.Show();
            boardingPassForm.Activate();
            boardingPassForm.WindowState = FormWindowState.Normal;
        }

        private void bookToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            if (bookFlightForm == null || bookFlightForm.IsDisposed)
            {
                bookFlightForm = new BookFlightForm(employee);
                bookFlightForm.MdiParent = this;
            }

            bookFlightForm.Show();
            bookFlightForm.Activate();
            bookFlightForm.WindowState = FormWindowState.Normal;
        }

        private void cancelToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if (cancelFlightForm == null || cancelFlightForm.IsDisposed)
            {
                cancelFlightForm = new CancelFlightForm(employee);
                cancelFlightForm.MdiParent = this;
            }

            cancelFlightForm.Show();
            cancelFlightForm.Activate();
            cancelFlightForm.WindowState = FormWindowState.Normal;
        }

        private void informationToolStripMenuItem_Click(object sender, System.EventArgs e)
        {
            if(passengerInfoForm == null || passengerInfoForm.IsDisposed)
            {
                passengerInfoForm = new PassengerInfoForm();
                passengerInfoForm.MdiParent = this;
            }

            passengerInfoForm.Show();
            passengerInfoForm.Activate();
            passengerInfoForm.WindowState = FormWindowState.Normal;
        }
    }
}
