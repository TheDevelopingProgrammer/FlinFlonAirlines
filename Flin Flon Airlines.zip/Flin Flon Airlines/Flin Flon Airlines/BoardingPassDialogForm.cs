﻿//BoardingPassDialogForm.cs
using System.Drawing;
using System.Net.Mail;
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class BoardingPassDialogForm : Form
    {
        private BookingAgent employee;
        private Passenger passenger;
        private Flight flight;
        private LoadingForm loadingForm;
        private bool mailSent;

        public BoardingPassDialogForm(BookingAgent employee, Passenger passenger, Flight flight)
        {
            InitializeComponent();
            this.employee = employee;
            this.passenger = passenger;
            this.flight = flight;
        }

        private void BoardingPassDialogForm_Load(object sender, System.EventArgs e)
        {
            nameTextBox.Text = passenger.FirstName + " " + passenger.LastName;
            classTextBox.Text = Database.GetFlightClass(passenger, flight);
            seatTextBox.Text = Database.GetFlightSeat(passenger, flight);
            fromTextBox.Text = flight.Origin;
            destinationTextBox.Text = flight.Destination;
            dateTextBox.Text = flight.DepartureTime.ToString("MM/dd/yyyy");
            timeTextBox.Text = flight.DepartureTime.ToString("hh:mm:ss tt");
            flightTextBox.Text = flight.Id.ToString();
        }

        private void emailButton_Click(object sender, System.EventArgs e)
        {
            Rectangle bound = RectangleToScreen(ClientRectangle);
            using (Bitmap bm = new Bitmap(bound.Width, bound.Height))
            using (Graphics g = Graphics.FromImage(bm))
            {
                g.CopyFromScreen(new Point(bound.Left, bound.Top), Point.Empty, bound.Size);

                System.IO.Stream stream = new System.IO.MemoryStream();
                bm.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                stream.Position = 0;

                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                MailMessage mail = new MailMessage("FlinFlonAirlines@gmail.com", passenger.EmailAddress);
                Attachment attach = new Attachment(stream, "Boarding Pass.jpg");
                mail.Subject = "Flin Flon Airlines Boarding Pass";
                mail.Body = "The attached is your boarding pass.\nThank you for choosing Flin Flon Airlines!";
                mail.Attachments.Add(attach);
                client.EnableSsl = true;
                client.Credentials = new System.Net.NetworkCredential("FlinFlonAirlines@gmail.com", "flinflonairlines330");
                client.SendCompleted += Client_SendCompleted;
                client.SendAsync(mail, null);

                mailSent = false;

                if (loadingForm == null || loadingForm.IsDisposed)
                    loadingForm = new LoadingForm();

                if (loadingForm.ShowDialog() == DialogResult.Cancel && !mailSent)
                    client.SendAsyncCancel();
            }
        }

        private void Client_SendCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (!e.Cancelled)
            {
                loadingForm.Dispose();
                DialogResult = DialogResult.OK;
                Dispose();
            }

            mailSent = true;
        }

        private void cancelButton_Click(object sender, System.EventArgs e)
        {
            Dispose();
        }
    }
}
