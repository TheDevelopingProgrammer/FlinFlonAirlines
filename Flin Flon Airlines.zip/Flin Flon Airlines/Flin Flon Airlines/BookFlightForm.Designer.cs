﻿namespace Flin_Flon_Airlines
{
    partial class BookFlightForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.passengerListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.refreshPassengerButton = new System.Windows.Forms.Button();
            this.refreshFlightButton = new System.Windows.Forms.Button();
            this.flightListView = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.bookFlightButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.classComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.seatComboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose A Passenger:";
            // 
            // passengerListView
            // 
            this.passengerListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.passengerListView.FullRowSelect = true;
            this.passengerListView.HideSelection = false;
            this.passengerListView.Location = new System.Drawing.Point(15, 25);
            this.passengerListView.MultiSelect = false;
            this.passengerListView.Name = "passengerListView";
            this.passengerListView.Size = new System.Drawing.Size(574, 97);
            this.passengerListView.TabIndex = 1;
            this.passengerListView.UseCompatibleStateImageBehavior = false;
            this.passengerListView.View = System.Windows.Forms.View.Details;
            this.passengerListView.SelectedIndexChanged += new System.EventHandler(this.passengerListView_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Id";
            this.columnHeader1.Width = 30;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "First Name";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Last Name";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Email";
            this.columnHeader4.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Address";
            this.columnHeader5.Width = 80;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Phone";
            this.columnHeader6.Width = 80;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Credit Card";
            this.columnHeader7.Width = 80;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Disability";
            // 
            // refreshPassengerButton
            // 
            this.refreshPassengerButton.Location = new System.Drawing.Point(602, 63);
            this.refreshPassengerButton.Name = "refreshPassengerButton";
            this.refreshPassengerButton.Size = new System.Drawing.Size(75, 23);
            this.refreshPassengerButton.TabIndex = 2;
            this.refreshPassengerButton.Text = "Refresh";
            this.refreshPassengerButton.UseVisualStyleBackColor = true;
            this.refreshPassengerButton.Click += new System.EventHandler(this.refreshPassengerButton_Click);
            // 
            // refreshFlightButton
            // 
            this.refreshFlightButton.Location = new System.Drawing.Point(602, 180);
            this.refreshFlightButton.Name = "refreshFlightButton";
            this.refreshFlightButton.Size = new System.Drawing.Size(75, 23);
            this.refreshFlightButton.TabIndex = 5;
            this.refreshFlightButton.Text = "Refresh";
            this.refreshFlightButton.UseVisualStyleBackColor = true;
            this.refreshFlightButton.Click += new System.EventHandler(this.refreshFlightButton_Click);
            // 
            // flightListView
            // 
            this.flightListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.flightListView.FullRowSelect = true;
            this.flightListView.HideSelection = false;
            this.flightListView.Location = new System.Drawing.Point(15, 142);
            this.flightListView.MultiSelect = false;
            this.flightListView.Name = "flightListView";
            this.flightListView.Size = new System.Drawing.Size(574, 97);
            this.flightListView.TabIndex = 4;
            this.flightListView.UseCompatibleStateImageBehavior = false;
            this.flightListView.View = System.Windows.Forms.View.Details;
            this.flightListView.SelectedIndexChanged += new System.EventHandler(this.flightListView_SelectedIndexChanged);
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Id";
            this.columnHeader9.Width = 30;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Origin";
            this.columnHeader10.Width = 90;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Destination";
            this.columnHeader11.Width = 90;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Departure Time";
            this.columnHeader12.Width = 100;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Seats";
            this.columnHeader13.Width = 43;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Seats Left";
            this.columnHeader14.Width = 63;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Choose A Flight:";
            // 
            // bookFlightButton
            // 
            this.bookFlightButton.Location = new System.Drawing.Point(307, 340);
            this.bookFlightButton.Name = "bookFlightButton";
            this.bookFlightButton.Size = new System.Drawing.Size(75, 23);
            this.bookFlightButton.TabIndex = 6;
            this.bookFlightButton.Text = "Book Flight";
            this.bookFlightButton.UseVisualStyleBackColor = true;
            this.bookFlightButton.Click += new System.EventHandler(this.bookFlightButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.classComboBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.seatComboBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(251, 245);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(187, 89);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Preferences";
            // 
            // classComboBox
            // 
            this.classComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.classComboBox.FormattingEnabled = true;
            this.classComboBox.Items.AddRange(new object[] {
            "First",
            "Business",
            "Economy"});
            this.classComboBox.Location = new System.Drawing.Point(44, 53);
            this.classComboBox.Name = "classComboBox";
            this.classComboBox.Size = new System.Drawing.Size(121, 21);
            this.classComboBox.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Class:";
            // 
            // seatComboBox
            // 
            this.seatComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.seatComboBox.FormattingEnabled = true;
            this.seatComboBox.Items.AddRange(new object[] {
            "Aisle",
            "Window",
            "None"});
            this.seatComboBox.Location = new System.Drawing.Point(44, 13);
            this.seatComboBox.Name = "seatComboBox";
            this.seatComboBox.Size = new System.Drawing.Size(121, 21);
            this.seatComboBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Seat:";
            // 
            // BookFlightForm
            // 
            this.AcceptButton = this.bookFlightButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 375);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bookFlightButton);
            this.Controls.Add(this.refreshFlightButton);
            this.Controls.Add(this.flightListView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.refreshPassengerButton);
            this.Controls.Add(this.passengerListView);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "BookFlightForm";
            this.ShowIcon = false;
            this.Text = "Book Flight";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView passengerListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Button refreshPassengerButton;
        private System.Windows.Forms.Button refreshFlightButton;
        private System.Windows.Forms.ListView flightListView;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.Button bookFlightButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox seatComboBox;
        private System.Windows.Forms.ComboBox classComboBox;
        private System.Windows.Forms.Label label4;
    }
}