﻿//AddFlightForm.cs
using System;
using System.Linq;
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class AddFlightForm : Form
    {
        private SystemAdmin employee;

        public AddFlightForm(SystemAdmin employee)
        {
            InitializeComponent();
            this.employee = employee;
        }

        private async void addButton_Click(object sender, EventArgs e)
        {
            if (originTextBox.Text.Length <= 0 || destinationTextBox.Text.Length <= 0)
            {
                Controls.OfType<TextBox>().Where(tbox => tbox.Text.Length <= 0).Last().Focus();
                MessageBox.Show("Please confirm inputs and try again", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            else if(dateTimePicker1.Value < DateTime.Now)
            {
                MessageBox.Show("Invalid departure time", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            else if(seatsNumericUpDown.Value <= 0)
            {
                MessageBox.Show("Invalid number of seats", "Invalid Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string origin = originTextBox.Text;
            string destination = destinationTextBox.Text;
            DateTime departureTime = dateTimePicker1.Value;
            int seats = (int)seatsNumericUpDown.Value;
            int seatsLeft = seats;

            await employee.AddFlight(new Flight(origin, destination, departureTime, seats, seatsLeft));

            MessageBox.Show("Flight Added", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Dispose();
        }
    }
}
