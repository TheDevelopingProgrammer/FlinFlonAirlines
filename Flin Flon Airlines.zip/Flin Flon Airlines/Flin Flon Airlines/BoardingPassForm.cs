﻿//BoardingPassForm.cs
using System.Collections.Generic;
using System.Windows.Forms;

namespace Flin_Flon_Airlines
{
    public partial class BoardingPassForm : Form
    {
        private BookingAgent employee;

        public BoardingPassForm(BookingAgent employee)
        {
            InitializeComponent();
            this.employee = employee;
            UpdatePassengerComboBox();
        }

        public void UpdatePassengerComboBox()
        {
            passengerComboBox.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();
            passengerComboBox.Items.AddRange(GlobalVars.passengerList.ToArray());
        }

        private void passengerComboBox_DropDown(object sender, System.EventArgs e)
        {
            if (passengerComboBox.SelectedItem == null)
                flightListView.Items.Clear();
        }

        private void UpdateFlightListView()
        {
            flightListView.Items.Clear();

            if (passengerComboBox.SelectedItem != null)
            {
                Passenger passenger = (Passenger)passengerComboBox.SelectedItem;
                passenger.Update();
                List<Flight> flights = passenger.BookedFlights;

                foreach(Flight flight in flights)
                {
                    if (!passenger.HasBoardingPass(flight))
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = flight.Id.ToString();
                        item.SubItems.Add(flight.Origin);
                        item.SubItems.Add(flight.Destination);
                        item.SubItems.Add(flight.DepartureTime.ToString());
                        item.SubItems.Add(flight.Seats.ToString());
                        item.SubItems.Add(flight.SeatsLeft.ToString());
                        flightListView.Items.Add(item);
                    }
                }
            }
        }

        private void passengerComboBox_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdateFlightListView();
        }

        private async void issueButton_Click(object sender, System.EventArgs e)
        {
            if (passengerComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a passenger", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else if (flightListView.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Please select a flight to issue boarding pass for", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Flight flight = Flight.GetFlight(int.Parse(flightListView.SelectedItems[0].Text));

            BoardingPassDialogForm boardingPassDialogForm = new BoardingPassDialogForm(employee, (Passenger)passengerComboBox.SelectedItem, flight);
            DialogResult result = boardingPassDialogForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                await employee.IssueBoardingPass((Passenger)passengerComboBox.SelectedItem, flight);
                MessageBox.Show("Boarding pass issued", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateFlightListView();
            }
        }
    }
}
