﻿//Database.cs
using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Flin_Flon_Airlines
{
    static class Database
    {
        public static readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Airline.mdf;Integrated Security=True";

        public static async Task<bool> UserExists(string username)
        {
            bool found = false;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT Username FROM Login", conn))
            {
                conn.Open();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                if (reader.HasRows)
                {
                    while (reader.Read() && !found)
                    {
                        if (reader.GetString(0) == username)
                            found = true;
                    }
                }
            }

            return found;
        }

        public static async Task<int> GetUserId(string username)
        {
            int Id = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT Id, Username FROM Login", conn))
            {
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                if(reader.HasRows) 
                {
                    while(reader.Read() && Id == 0)
                    {
                        if(reader.GetString(reader.GetOrdinal("Username")) == username)
                            Id = reader.GetInt32(reader.GetOrdinal("Id"));
                    }
                }
            }

            return Id;
        }

        public static async Task<bool> MatchLogin(string username, string password)
        {
            bool match = false;

            if (await UserExists(username))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(@"SELECT Password FROM Login
                                                         WHERE Id = @Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Id", await GetUserId(username));
                    await conn.OpenAsync();
                    SqlDataReader reader = await cmd.ExecuteReaderAsync();

                    if (reader.HasRows)
                    {
                        if (await reader.ReadAsync() && !match)
                        {
                            if (reader.GetString(0) == password)
                                match = true;
                        }
                    }
                }
            }

            return match;
        }

        public static async Task<bool> IsSystemAdmin(string username)
        {
            bool isSystemAdmin = false;

            if(await UserExists(username))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(@"SELECT Admin FROM Login
                                                         WHERE Id = @Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Id", GetUserId(username));
                    await conn.OpenAsync();
                    SqlDataReader reader = await cmd.ExecuteReaderAsync();

                    if (reader.HasRows)
                    {
                        if (reader.Read())
                        {
                            isSystemAdmin = reader.GetBoolean(0);
                        }
                    }
                }
            }

            return isSystemAdmin;
        }

        public static async Task AddPassenger(Passenger passenger)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"INSERT INTO Passenger(FirstName, LastName, Email, Address, Phone, CreditCard, Disability)
                                                    VALUES(@firstName, @lastName, @emailAddress, @homeAddress, @phoneNumber, @creditCardNumber, @disability)", conn))
            {
                cmd.Parameters.AddWithValue("@firstName", passenger.FirstName);
                cmd.Parameters.AddWithValue("@lastName", passenger.LastName);
                cmd.Parameters.AddWithValue("@emailAddress", passenger.EmailAddress);
                cmd.Parameters.AddWithValue("@homeAddress", passenger.HomeAddress);
                cmd.Parameters.AddWithValue("@phoneNumber", passenger.PhoneNumber);
                cmd.Parameters.AddWithValue("@creditCardNumber", passenger.CreditCardNumber);
                cmd.Parameters.AddWithValue("@disability", passenger.Disability);
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public static async Task AddFlight(Flight flight)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"INSERT INTO Flight(Origin, Destination, DepartureTime, Seats, SeatsLeft)
                                                    VALUES(@origin, @destination, @departureTime, @seats, @seatsLeft)", conn))
            {
                cmd.Parameters.AddWithValue("@origin", flight.Origin);
                cmd.Parameters.AddWithValue("@destination", flight.Destination);
                cmd.Parameters.AddWithValue("@departureTime", flight.DepartureTime);
                cmd.Parameters.AddWithValue("@seats", flight.Seats);
                cmd.Parameters.AddWithValue("@seatsLeft", flight.SeatsLeft);
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public static async Task UpdateFlight(Flight flight)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"UPDATE Flight
                                                        SET Origin = @origin, Destination = @destination, DepartureTime = @departureTime, Seats = @seats, SeatsLeft = @seatsLeft
                                                        WHERE Id = @id", conn))
            {
                cmd.Parameters.AddWithValue("@origin", flight.Origin);
                cmd.Parameters.AddWithValue("@destination", flight.Destination);
                cmd.Parameters.AddWithValue("@departureTime", flight.DepartureTime);
                cmd.Parameters.AddWithValue("@seats", flight.Seats);
                cmd.Parameters.AddWithValue("@seatsLeft", flight.SeatsLeft);
                cmd.Parameters.AddWithValue("@id", flight.Id);
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public static string GetFlightClass(Passenger passenger, Flight flight)
        {
            string flightClass = string.Empty;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT Class FROM FlightReservation
                                                    WHERE PassengerId = @passengerId AND FlightId = @flightId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    if(reader.Read())
                    {
                        flightClass += reader.GetString(0);
                    }
                }
            }

            return flightClass;
        }

        public static string GetFlightSeat(Passenger passenger, Flight flight)
        {
            string seat = string.Empty;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT Seat FROM FlightReservation
                                                    WHERE PassengerId = @passengerId AND FlightId = @flightId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        seat += reader.GetString(0);
                    }
                }
            }

            return seat;
        }

        public static Employee GetEmployee(int id)
        {
            Employee employee = null;
            string username;
            string password;
            bool isAdmin;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT * FROM Login
                                                    WHERE Id = @id", conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    if(reader.Read())
                    {
                        id = reader.GetInt32(reader.GetOrdinal("Id"));
                        username = reader.GetString(reader.GetOrdinal("Username"));
                        password = reader.GetString(reader.GetOrdinal("Password"));
                        isAdmin = reader.GetBoolean(reader.GetOrdinal("Admin"));

                        if (isAdmin)
                            employee = new SystemAdmin(id, username, password, isAdmin);

                        else
                            employee = new BookingAgent(id, username, password, isAdmin);
                    }
                }
            }

            return employee;
        }

        public static List<Passenger> GetPassengerList()
        {
            List<Passenger> passengers = new List<Passenger>();
            int id;
            string firstName;
            string lastName;
            string emailAddress;
            string homeAddress;
            string phoneNumber;
            string creditCardNumber;
            bool disability;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT * FROM Passenger", conn))
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    while(reader.Read())
                    {
                        id = reader.GetInt32(reader.GetOrdinal("Id"));
                        firstName = reader.GetString(reader.GetOrdinal("FirstName"));
                        lastName = reader.GetString(reader.GetOrdinal("LastName"));
                        emailAddress = reader.GetString(reader.GetOrdinal("Email"));
                        homeAddress = reader.GetString(reader.GetOrdinal("Address"));
                        phoneNumber = reader.GetString(reader.GetOrdinal("Phone"));
                        creditCardNumber = reader.GetString(reader.GetOrdinal("CreditCard"));
                        disability = reader.GetBoolean(reader.GetOrdinal("Disability"));
                        passengers.Add(new Passenger(id, firstName, lastName, emailAddress, homeAddress, phoneNumber, creditCardNumber, disability));
                    }
                }
            }

            return passengers;
        }

        public static List<Flight> GetFlightList()
        {
            List<Flight> flights = new List<Flight>();
            int id;
            string origin;
            string destination;
            DateTime departureTime;
            int seats;
            int seatsLeft;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT * FROM Flight", conn))
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader.GetInt32(reader.GetOrdinal("Id"));
                        origin = reader.GetString(reader.GetOrdinal("Origin"));
                        destination = reader.GetString(reader.GetOrdinal("Destination"));
                        departureTime = reader.GetDateTime(reader.GetOrdinal("DepartureTime"));
                        seats = reader.GetInt32(reader.GetOrdinal("Seats"));
                        seatsLeft = reader.GetInt32(reader.GetOrdinal("SeatsLeft"));
                        flights.Add(new Flight(id, origin, destination, departureTime, seats, seatsLeft));
                    }
                }
            }

            return flights;
        }

        public static bool FlightBooked(Passenger passenger, Flight flight)
        {
            bool booked = false;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT * FROM FlightReservation
                                                    WHERE PassengerId = @passengerId AND FlightId = @flightId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        booked = true;
                    }
                }
            }

            return booked;
        }

        public static async Task BookFlight(Passenger passenger, Flight flight, string flightClass, string seat)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = conn;

                if (!Database.FlightBooked(passenger, flight))
                {
                    cmd.CommandText = @"INSERT INTO FlightReservation(PassengerId, FlightId, Count, Class, Seat)
                                        VALUES(@passengerId, @flightId, 1, @class, @seat)";
                    cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                    cmd.Parameters.AddWithValue("@flightId", flight.Id);
                    cmd.Parameters.AddWithValue("@class", flightClass);
                    cmd.Parameters.AddWithValue("@seat", seat);
                }

                else
                {
                    cmd.Parameters.Clear();
                    cmd.CommandText = @"UPDATE FlightReservation
                                        SET Count = Count + 1
                                        WHERE PassengerId = @passengerId AND FlightId = @flightId";
                    cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                    cmd.Parameters.AddWithValue("@flightId", flight.Id);
                }

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                cmd.Parameters.Clear();
                cmd.CommandText = @"UPDATE Flight
                                    SET SeatsLeft = SeatsLeft - 1
                                    WHERE Id = @flightId";
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public static int GetFlightReservationCount(Passenger passenger, Flight flight)
        {
            int count = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT Count FROM FlightReservation
                                                    WHERE PassengerId = @passengerId AND FlightId = @flightId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        count = reader.GetInt32(0);
                    }
                }
            }

            return count;
        }

        public static async Task IssueBoardingPass(Passenger passenger, Flight flight)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"UPDATE FlightReservation
                                                    SET BoardingPass = 1
                                                    WHERE PassengerId = @passengerId AND FlightId = @flightId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                conn.Open();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public static async Task CancelFlight(Passenger passenger, Flight flight)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = conn;

                if (Database.GetFlightReservationCount(passenger, flight) > 1)
                {
                    cmd.CommandText = @"UPDATE FlightReservation
                                        SET Count = Count - 1
                                        WHERE PassengerId = @passengerId AND FlightId = @flightId";
                    cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                    cmd.Parameters.AddWithValue("@flightId", flight.Id);
                }

                else
                {
                    cmd.CommandText = @"DELETE FROM FlightReservation
                                        WHERE PassengerId = @passengerId AND FlightId = @flightId";
                    cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                    cmd.Parameters.AddWithValue("@flightId", flight.Id);
                }
                
                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();

                cmd.Parameters.Clear();
                cmd.CommandText = @"UPDATE Flight
                                    SET SeatsLeft = SeatsLeft + 1
                                    WHERE Id = @flightId";
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public static bool HasBoardingPass(Passenger passenger, Flight flight)
        {
            bool hasBoardingPass = false;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT BoardingPass FROM FlightReservation
                                                    WHERE PassengerId = @passengerId AND FlightId = @flightId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                cmd.Parameters.AddWithValue("@flightId", flight.Id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if(reader.HasRows)
                {
                    if(reader.Read())
                    {
                        hasBoardingPass = reader.GetBoolean(0);
                    }
                }
            }

            return hasBoardingPass;
        }

        public static List<Flight> GetBookedFlights(Passenger passenger)
        {
            List<Flight> bookedFlights = new List<Flight>();
            int flightId;

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(@"SELECT FlightId FROM FlightReservation
                                                    WHERE PassengerId = @passengerId", conn))
            {
                cmd.Parameters.AddWithValue("@passengerId", passenger.Id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        flightId = reader.GetInt32(0);
                        bookedFlights.Add(Flight.GetFlight(flightId));
                    }
                }
            }

            return bookedFlights;
        }
    }
}
