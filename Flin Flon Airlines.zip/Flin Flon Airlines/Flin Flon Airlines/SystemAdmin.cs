﻿//SystemAdmin.cs
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Flin_Flon_Airlines
{
    public class SystemAdmin : BookingAgent
    {
        public SystemAdmin(int id, string username, string password, bool isAdmin) : base(id, username, password, isAdmin)
        {
        }

        public async Task AddFlight(Flight flight)
        {
            await Database.AddFlight(flight);
            UpdateFlightList();
        }

        private void UpdateFlightList()
        {
            GlobalVars.flightList.Clear();
            List<Flight> flights = Database.GetFlightList();

            if (flights.Count > 0)
                GlobalVars.flightList.AddRange(flights);
        }

        public async Task UpdateFlight(Flight flight)
        {
            await Database.UpdateFlight(flight);
            UpdateFlightList();
        }

        public override void ShowForm(LoginForm logForm)
        {
            loginForm = logForm;
            SystemAdminForm form = new SystemAdminForm(this);
            form.Text = Username + " - System Admin";
            form.FormClosed += Form_FormClosed;
            loginForm.Hide();
            form.Show();
        }
    }
}
