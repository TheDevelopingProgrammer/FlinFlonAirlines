﻿//Flight.cs
using System;

namespace Flin_Flon_Airlines
{
    public class Flight : IEquatable<Flight>
    {
        private int id;
        private string origin;
        private string destination;
        private DateTime departureTime;
        private int seats;
        private int seatsLeft;

        public Flight(int id, string origin, string destination, DateTime departureTime, int seats, int seatsLeft)
        {
            Id = id;
            Origin = origin;
            Destination = destination;
            DepartureTime = departureTime;
            Seats = seats;
            SeatsLeft = seatsLeft;
        }

        public Flight(string origin, string destination, DateTime departureTime, int seats, int seatsLeft)
        {
            Origin = origin;
            Destination = destination;
            DepartureTime = departureTime;
            Seats = seats;
            SeatsLeft = seatsLeft;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Origin
        {
            get { return origin; }
            set { origin = value; }
        }

        public string Destination
        {
            get { return destination; }
            set { destination = value; }
        }

        public DateTime DepartureTime
        {
            get { return departureTime; }
            set { departureTime = value; }
        }

        public int Seats
        {
            get { return seats; }
            set { seats = value; }
        }

        public int SeatsLeft
        {
            get { return seatsLeft; }
            set { seatsLeft = value; }
        }

        public static Flight GetFlight(int flightId)
        {
            return Database.GetFlightList().Find(f => f.Id == flightId);
        }

        public bool Equals(Flight other)
        {
            return this.Id == other.Id;
        }

        public void Update()
        {
            Flight flight = GetFlight(Id);

            if (flight != null)
            {
                Id = flight.Id;
                Origin = flight.origin;
                Destination = flight.Destination;
                DepartureTime = flight.DepartureTime;
                Seats = flight.Seats;
                SeatsLeft = flight.SeatsLeft;
            }
        }

        public override string ToString()
        {
            return Id.ToString();
        }
    }
}
