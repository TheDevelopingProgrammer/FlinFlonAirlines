﻿//BookFlightForm.cs
using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Flin_Flon_Airlines
{
    public partial class BookFlightForm : Form
    {
        private BookingAgent employee;
        private Passenger passenger;
        private Flight flight;

        public BookFlightForm(BookingAgent employee)
        {
            InitializeComponent();
            this.employee = employee;
            UpdatePassengerListView();
            UpdateFlightListView();
        }

        public void UpdatePassengerListView()
        {
            passenger = null;
            passengerListView.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();

            List<ListViewItem> items = new List<ListViewItem>();

            foreach (Passenger passenger in GlobalVars.passengerList)
            {
                ListViewItem item = new ListViewItem();
                item.Text = passenger.Id.ToString();
                item.SubItems.Add(passenger.FirstName);
                item.SubItems.Add(passenger.LastName);
                item.SubItems.Add(passenger.EmailAddress);
                item.SubItems.Add(passenger.HomeAddress);
                item.SubItems.Add(passenger.PhoneNumber);
                item.SubItems.Add(passenger.CreditCardNumber);
                item.SubItems.Add(passenger.Disability.ToString());
                items.Add(item);
            }

            passengerListView.Items.AddRange(items.ToArray());
        }

        public void UpdateFlightListView()
        {
            flight = null;
            flightListView.Items.Clear();
            GlobalVars.UpdatePassengerAndFlightList();

            List<ListViewItem> items = new List<ListViewItem>();

            foreach (Flight flight in GlobalVars.flightList)
            {
                ListViewItem item = new ListViewItem();
                item.Text = flight.Id.ToString();
                item.SubItems.Add(flight.Origin);
                item.SubItems.Add(flight.Destination);
                item.SubItems.Add(flight.DepartureTime.ToString());
                item.SubItems.Add(flight.Seats.ToString());
                item.SubItems.Add(flight.SeatsLeft.ToString());
                items.Add(item);
            }

            flightListView.Items.AddRange(items.ToArray());
        }

        private void refreshPassengerButton_Click(object sender, System.EventArgs e)
        {
            UpdatePassengerListView();
            UpdateFlightListView();
        }

        private void refreshFlightButton_Click(object sender, System.EventArgs e)
        {
            if (passenger != null)
                passenger.Update();

            if (flight != null)
                flight.Update();

            UpdateFlightListView();
        }

        private void passengerListView_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (passengerListView.SelectedItems.Count > 0)
            {
                passenger = Passenger.GetPassenger(int.Parse(passengerListView.SelectedItems[0].Text));
                UpdateFlightListView();
            }

            else
            {
                passenger = null;
                UpdateFlightListView();
            }
        }

        private void flightListView_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (flightListView.SelectedItems.Count > 0)
                flight = Flight.GetFlight(int.Parse(flightListView.SelectedItems[0].Text));

            else
                flight = null;
        }

        private async void bookFlightButton_Click(object sender, System.EventArgs e)
        {
            if (passenger == null || flight == null)
                MessageBox.Show("Please choose a passenger and flight to book", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (seatComboBox.SelectedItem == null || classComboBox.SelectedItem == null)
                MessageBox.Show("Please choose preferences for the flight", "Missing Field", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else
            {
                if (flight.SeatsLeft > 0)
                {
                    string seat = (string)seatComboBox.SelectedItem;
                    seat += " " + new Random().Next(1, flight.Seats + 1).ToString();
                    await employee.BookFlight(passenger, flight, (string)classComboBox.SelectedItem, seat);
                    passenger.Update();
                    MessageBox.Show("Successfully Booked", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    UpdateFlightListView();
                    seatComboBox.SelectedIndex = classComboBox.SelectedIndex = -1;
                }

                else
                {
                    MessageBox.Show("No more seats available", "Flight Full", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
