﻿//Passenger.cs
using System;
using System.Collections.Generic;

namespace Flin_Flon_Airlines
{
    public class Passenger
    {
        private int id;
        private string firstName;
        private string lastName;
        private string emailAddress;
        private string homeAddress;
        private string phoneNumber;
        private string creditCardNumber;
        private bool disability;
        private List<Flight> bookedFlights;

        public Passenger(int id, string firstName, string lastName, string emailAddress, string homeAddress, string phoneNumber, string creditCardNumber, bool disability)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            EmailAddress = emailAddress;
            HomeAddress = homeAddress;
            PhoneNumber = phoneNumber;
            CreditCardNumber = creditCardNumber;
            Disability = disability;
            BookedFlights = Database.GetBookedFlights(this);
        }

        public Passenger(string firstName, string lastName, string emailAddress, string homeAddress, string phoneNumber, string creditCardNumber, bool disability)
        {
            FirstName = firstName;
            LastName = lastName;
            EmailAddress = emailAddress;
            HomeAddress = homeAddress;
            PhoneNumber = phoneNumber;
            CreditCardNumber = creditCardNumber;
            Disability = disability;
        }

        public bool HasBoardingPass(Flight flight)
        {
            return Database.HasBoardingPass(this, flight);
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }

        public string HomeAddress
        {
            get { return homeAddress; }
            set { homeAddress = value; }
        }

        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }

        public string CreditCardNumber
        {
            get { return creditCardNumber; }
            set { creditCardNumber = value; }
        }

        public bool Disability
        {
            get { return disability; }
            set { disability = value; }
        }

        public List<Flight> BookedFlights
        {
            get { return bookedFlights; }
            set { bookedFlights = value; }
        }

        public static Passenger GetPassenger(int passengerId)
        {
            return Database.GetPassengerList().Find(p => p.Id == passengerId);
        }

        public void Update()
        {
            Passenger passenger = GetPassenger(Id);

            if(passenger != null)
            {
                Id = passenger.Id;
                FirstName = passenger.FirstName;
                LastName = passenger.LastName;
                EmailAddress = passenger.EmailAddress;
                HomeAddress = passenger.HomeAddress;
                PhoneNumber = passenger.PhoneNumber;
                CreditCardNumber = passenger.CreditCardNumber;
                Disability = passenger.Disability;
                BookedFlights = Database.GetBookedFlights(this);
            }
        }

        public override string ToString()
        {
            return FirstName + " " + lastName;
        }
    }
}
