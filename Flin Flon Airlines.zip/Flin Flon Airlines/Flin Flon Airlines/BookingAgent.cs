﻿//BookingAgent.cs
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Flin_Flon_Airlines
{
    public class BookingAgent : Employee
    {
        public BookingAgent(int id, string username, string password, bool isAdmin) : base(id, username, password, isAdmin)
        {
        }

        public async Task AddPassenger(Passenger passenger)
        {
            await Database.AddPassenger(passenger);
            UpdatePassengerList();
        }

        private void UpdatePassengerList()
        {
            GlobalVars.passengerList.Clear();
            List<Passenger> passengers = Database.GetPassengerList();

            if (passengers.Count > 0)
                GlobalVars.passengerList.AddRange(passengers);
        }

        public async Task BookFlight(Passenger passenger, Flight flight, string flightClass, string seat)
        {
            await Database.BookFlight(passenger, flight, flightClass, seat);
        }

        public async Task CancelFlight(Passenger passenger, Flight flight)
        {
            await Database.CancelFlight(passenger, flight);
        }

        public async Task IssueBoardingPass(Passenger passenger, Flight flight)
        {
            await Database.IssueBoardingPass(passenger, flight);
        }

        public override void ShowForm(LoginForm logForm)
        {
            loginForm = logForm;
            BookingAgentForm form = new BookingAgentForm(this);
            form.Text = Username + " - Booking Agent";
            form.FormClosed += Form_FormClosed;
            loginForm.Hide();
            form.Show();
        }
    }
}
